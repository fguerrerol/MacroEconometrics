wash <- function(X) {
  unclass(as.matrix(unname(X)))[]
}